import { registerDeckStage } from './runtime/deck-stage.js';

/**
 * Mount a framework-free deck with stable slide shells. The caller owns URLs,
 * timers and navigation intents. Refresh only redraws one shell's contents.
 * Importing this module is safe on a server; mounting requires a DOM element.
 */
export function createLiveDeck(container, options = {}) {
  const view = container?.ownerDocument?.defaultView;
  if (!view || typeof container.appendChild !== 'function') throw new TypeError('createLiveDeck requires a DOM container');
  const { slides: input = [], renderSlide, onIndexChange, onNavigate } = options;
  if (!Array.isArray(input)) throw new TypeError('slides must be an array');
  if (typeof renderSlide !== 'function') throw new TypeError('renderSlide must be a function');
  const seen = new Set();
  const slides = input.map(slide => {
    if (!slide || typeof slide.id !== 'string' || !slide.id || seen.has(slide.id)) throw new TypeError('Each slide needs a unique non-empty string id');
    seen.add(slide.id);
    return Object.freeze({ ...slide, label: slide.label ?? slide.id });
  });
  const Runtime = registerDeckStage(view);
  if (Runtime.liveDeckVersion !== 1) throw new Error('An older deck-stage is already registered. Load the bundled Storydeck runtime before mounting a live deck.');
  const document = container.ownerDocument;
  const element = document.createElement('deck-stage');
  for (const name of ['embedded', 'no-rail', 'noscale', 'no-hash', 'external-navigation']) element.setAttribute(name, '');
  element.setAttribute('tabindex', '0');
  element.setAttribute('aria-label', 'Slide presentation');
  const clamp = value => slides.length ? Math.max(0, Math.min(slides.length - 1, Number.isFinite(value) ? Math.floor(value) : 0)) : -1;
  let current = clamp(options.index ?? 0), ready = false, destroyed = false, applying = false;
  const shells = slides.map(slide => {
    const shell = document.createElement('section');
    shell.dataset.slideId = slide.id;
    shell.dataset.label = slide.label;
    element.appendChild(shell);
    return shell;
  });
  function refresh(index = current) {
    if (destroyed || !slides.length) return;
    const target = clamp(index);
    renderSlide(shells[target], { slide: slides[target], index: target, active: target === current });
  }
  function applyIndex() {
    if (!ready || element.index === current || current < 0) return;
    applying = true;
    try { element.goTo(current); } finally { applying = false; }
  }
  function change(index, reason) {
    if (destroyed || !slides.length) return;
    const target = clamp(index);
    if (target === current) { applyIndex(); return; }
    const previousIndex = current;
    current = target;
    applyIndex();
    onIndexChange?.(current, { previousIndex, slide: slides[current], reason });
    refresh(previousIndex);
    refresh(current);
  }
  function onChange(event) {
    if (event.target !== element || destroyed || applying) return;
    if (!ready) { ready = true; applyIndex(); return; }
    change(event.detail.index, event.detail.reason);
  }
  function onIntent(event) {
    if (!destroyed && event.target === element) onNavigate?.(event.detail);
  }
  element.addEventListener('slidechange', onChange);
  element.addEventListener('navigationintent', onIntent);
  function fit() {
    if (destroyed) return;
    const bounds = container.getBoundingClientRect();
    const width = Math.max(1, Math.round(container.clientWidth || bounds.width || 1920));
    const height = Math.max(1, Math.round(container.clientHeight || bounds.height || 1080));
    if (element.getAttribute('width') !== String(width)) element.setAttribute('width', String(width));
    if (element.getAttribute('height') !== String(height)) element.setAttribute('height', String(height));
  }
  let observer;
  try {
    slides.forEach((_, index) => refresh(index));
    fit();
    container.appendChild(element);
    if (typeof view.ResizeObserver === 'function') {
      observer = new view.ResizeObserver(fit);
      observer.observe(container);
    } else view.addEventListener('resize', fit);
  } catch (error) {
    element.removeEventListener('slidechange', onChange);
    element.removeEventListener('navigationintent', onIntent);
    element.remove();
    throw error;
  }
  return Object.freeze({
    goTo(index) { change(index, 'api'); },
    refresh,
    get currentIndex() { return current; },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      observer?.disconnect();
      view.removeEventListener('resize', fit);
      element.removeEventListener('slidechange', onChange);
      element.removeEventListener('navigationintent', onIntent);
      element.remove();
    },
  });
}
