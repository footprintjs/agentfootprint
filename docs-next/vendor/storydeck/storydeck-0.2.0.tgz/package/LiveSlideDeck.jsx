'use client';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { createLiveDeck } from './live.js';

/** Optional React rendering over the same framework-free, stable-shell host. */
export default function LiveSlideDeck({ slides, index = 0, renderSlide, onIndexChange, onNavigate, className, style }) {
  const host = useRef(null), instance = useRef(null), latest = useRef(null);
  latest.current = { slides, index, renderSlide, onIndexChange, onNavigate };
  const [entries, setEntries] = useState([]);
  // Equivalent arrays from a parent render must not replace the stage shells.
  const structure = JSON.stringify(slides.map(slide => slide.id));
  useEffect(() => {
    let alive = true;
    setEntries([]);
    const deck = createLiveDeck(host.current, {
      slides: latest.current.slides,
      index: latest.current.index,
      renderSlide(shell, context) {
        if (!alive) return;
        setEntries(previous => {
          const next = previous.slice();
          next[context.index] = { shell, context };
          return next;
        });
      },
      onIndexChange(next, detail) {
        latest.current.onIndexChange?.(next, { ...detail, slide: latest.current.slides[next] });
      },
      onNavigate(intent) { latest.current.onNavigate?.(intent); },
    });
    instance.current = deck;
    return () => { alive = false; instance.current = null; deck.destroy(); };
  }, [structure]);
  useEffect(() => { instance.current?.goTo(index); }, [index, structure]);
  useEffect(() => {
    for (const entry of entries) {
      const slide = slides[entry.context.index];
      if (slide) entry.shell.dataset.label = slide.label;
    }
  }, [slides, entries]);
  return <>
    <div ref={host} className={className} style={style} />
    {entries.filter(Boolean).map(({ shell, context }) => createPortal(
      renderSlide({ ...context, slide: slides[context.index] || context.slide }),
      shell,
      context.slide.id,
    ))}
  </>;
}
