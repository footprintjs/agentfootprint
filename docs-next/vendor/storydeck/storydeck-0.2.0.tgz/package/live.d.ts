export interface LiveSlide {
  readonly id: string;
  readonly label: string;
  readonly [metadata: string]: unknown;
}
export interface LiveSlideContext<S extends LiveSlide = LiveSlide> {
  readonly slide: S;
  readonly index: number;
  readonly active: boolean;
}
export interface NavigationIntent {
  readonly action: 'next' | 'previous' | 'goTo';
  readonly direction?: 1 | -1;
  /** Current index for next/previous; requested target for goTo. */
  readonly index: number;
  readonly currentIndex: number;
  readonly reason: string;
}
export interface LiveDeckOptions<S extends LiveSlide = LiveSlide> {
  readonly slides: readonly S[];
  readonly index?: number;
  readonly renderSlide: (shell: HTMLElement, context: LiveSlideContext<S>) => void;
  readonly onIndexChange?: (index: number, detail: { previousIndex: number; slide: S; reason: string }) => void;
  readonly onNavigate?: (intent: NavigationIntent) => void;
}
export interface LiveDeck {
  /** -1 for an empty deck. */
  readonly currentIndex: number;
  goTo(index: number): void;
  refresh(index?: number): void;
  destroy(): void;
}
/** No browser globals are accessed until this function is called. */
export function createLiveDeck<S extends LiveSlide = LiveSlide>(container: HTMLElement, options: LiveDeckOptions<S>): LiveDeck;
