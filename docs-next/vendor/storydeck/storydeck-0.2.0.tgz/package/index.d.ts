/** Framework-free Storydeck content and live-host APIs. */
export { createLiveDeck } from './live.js';
export type { LiveDeck, LiveDeckOptions, LiveSlide, LiveSlideContext, NavigationIntent } from './live.js';

export interface Section {
  readonly key: string;
  readonly label: string;
  readonly heading: string;
  readonly steps: readonly string[];
  readonly body: string;
}
export interface Post {
  readonly title: string;
  readonly description?: string;
  readonly date?: string;
  readonly author?: string;
  readonly slug?: string;
  readonly sections: readonly Section[];
  readonly deckSteps: readonly string[];
  readonly [meta: string]: unknown;
}
export interface Slide {
  readonly label: string;
  readonly html: string;
  readonly group?: string;
}
export function assemblePost<M extends object>(input: {
  meta: M;
  sections: readonly { key: string; label?: string; heading?: string; slides?: readonly string[] }[];
  bodyMd: string;
  deckSlides: readonly Slide[];
}): Post & M;
export function renderMarkdown(src: string): string;
export function splitBodyByMarkers(bodyMd: string): Record<string, string>;
export function buildSections(slides: readonly Slide[], options?: {
  headings?: Record<string, string>; bodies?: Record<string, string>;
}): Section[];
export function parseGroup(html: string): string | null;
export function finalStep(section: Section): string;
export function allSteps(sections: readonly Section[]): string[];
export function slugify(s: string): string;
export function scopeDeckCss(css: string): string;
