# storydeck

**One source, many lenses.** Write a piece of content once, render it three ways:

- **Read** — a detailed, SEO-first article (figure + prose per section).
- **Scroll** — scrollytelling: a pinned figure "stage" that advances as the narrative scrolls.
- **Watch** — an animated, click-through slide deck.

Same content, your lens. It's the footprintjs idea — *one canonical record, you choose the view* —
applied to content. A framework-free JavaScript core with optional React lenses; theme-agnostic; ships as source.

> Demo (dogfooded — storydeck explaining storydeck): **[footprintjs.github.io/storydeck](https://footprintjs.github.io/storydeck/)**
> First consumer: the **[footprintjs blog](https://footprintjs.github.io/blog/)**.

## Framework-free live slides

Import `createLiveDeck` from `storydeck/live` (or the package root). It works with ordinary DOM
containers, Vue mounted/unmounted hooks, Angular view/destroy hooks, and any other framework.
Neither core entry point imports React. Importing on a server does not access the DOM; call the
mount function only after the container exists.

```js
import { createLiveDeck } from 'storydeck/live';

const slides = [{ id: 'seed', label: 'Seed 1' }, { id: 'update', label: 'Update 1' }];
let phase = 0;
const deck = createLiveDeck(document.querySelector('#presentation'), {
  slides,
  index: 0,
  renderSlide(shell, { slide, index, active }) {
    // The shell stays mounted. Replace or update only its contents.
    shell.textContent = `${slide.label}: phase ${phase}${active ? ' (active)' : ''}`;
  },
  onIndexChange(index, { previousIndex, slide, reason }) {
    // The application may update its own URL or selected navigation item.
  },
  onNavigate(intent) {
    // Handle an internal phase here, or change the outer slide explicitly.
    if (intent.action === 'next') deck.goTo(deck.currentIndex + 1);
    else if (intent.action === 'previous') deck.goTo(deck.currentIndex - 1);
    else deck.goTo(intent.index);
  },
});

phase += 1;
deck.refresh();       // Renders the current shell, without changing slides or the URL.
deck.refresh(1);      // Renders only shell 1.
deck.goTo(1);         // Changes the outer slide; old/new active state is rendered.
deck.destroy();       // Idempotent cleanup; removes only this mounted deck.
```

Give the container an explicit size, such as `height: 70vh`. The embedded live stage follows its
container with a resize observer and uses unscaled coordinates. Keyboard intents are scoped to the
focused deck; links, inputs, and other interactive contents keep their normal behavior. The live
host always sets `no-hash` and `external-navigation`: it does not own a URL, a playback timer, or
what an internal step means. Calls to its public `goTo` API are not navigation intents.

`slides` is structural input: IDs must be unique. A new recording or slide list gets a new instance;
changing an internal step uses `refresh`. The renderer is called once for every initial shell, once
for the requested refresh, and for the old/new shells when the outer index changes. Callback
`onIndexChange(index, detail)` fires only when the outer index changes. Empty decks expose
`currentIndex === -1`. Frame data and passed slide descriptors are never modified by the host.

For plain HTML without a bundler, serve the package files and use an import map mapping
`storydeck/live` to `./packages/storydeck/live.js`. This entry has no third-party imports. Importing
the root for Markdown helpers also needs the normal `markdown-it` dependency resolution; use the
live subpath when only the DOM host is needed.

### Optional React adapter and migration

Previous React imports from `storydeck` move to `storydeck/react`; content helpers stay at the root:

```jsx
import { assemblePost } from 'storydeck';
import { LiveSlideDeck, PostView, StoryDeckProvider } from 'storydeck/react';

<LiveSlideDeck
  slides={slides}
  index={slideIndex}
  onNavigate={handleNavigation}
  onIndexChange={setSlideIndex}
  renderSlide={({ slide, active }) => <MyFigure slide={slide} phase={phase} active={active} />}
  style={{ height: '70vh' }}
/>
```

`LiveSlideDeck` uses React portals over the same live core. Stable IDs preserve outer shells and
React child state when phase data or equivalent slide arrays change. It disposes the core on
unmount. React and ReactDOM are optional peers; they are needed only for the `storydeck/react`
subpath. Vue and Angular can call the core mount/refresh/destroy methods directly, without
installing React or loading a React adapter. Core declarations do not import React types.

The original `SlideDeck({ steps })` remains the static HTML Watch lens. It now registers the
bundled runtime instead of injecting a separate public script. Do not load an older standalone
`deck-stage.js` before the live API: custom-element definitions cannot be replaced in a document;
the live host detects that incompatible registration and reports it.

## The model

The unit is a **Section** that owns **1..N slide steps** plus authored prose:

```
Section = { key, label, heading, steps: [slideHtml, …], body }   // body = rendered HTML
Post    = { …meta, sections: [Section, …], deckSteps: [slideHtml, …] }
```

- **Read** shows each section's *final* step as one figure + the prose.
- **Scroll** pins the figure and advances through the steps on scroll.
- **Watch** plays `deckSteps` (every slide) in a deck.

A section with several steps is a **group** — a progressive build collapses to one figure in Read,
plays in full in Watch/Scroll. One data model, three behaviours.

### A live figure, in Scroll

A section may carry a **`figure(beat)`** render function beside its `steps`. When it does, Scroll's
pinned stage renders `figure(beat)` instead of the slide canvas:

```jsx
const sections = assemblePost({ meta, sections: meta.sections, bodyMd, deckSlides }).sections
  .map((s) => ({ ...s, figure: (beat) => <MyChart beat={beat} /> }));

<ScrollyView sections={sections} />
```

Three things are true of it, and each is a decision:

- **It is hosted outside the scaled canvas.** `SlideFigure` fits a fixed 1920×1080 box to the column
  with a CSS transform; a live chart under a transform hit-tests in the transformed space while it
  measures in its own, so a brush lands in the wrong place. The live figure gets a plain block.
- **It is mounted once for the whole scroll.** The stage renders it without a key, so moving a beat
  re-renders the same subtree rather than tearing it down — a live figure is usually bound to
  something that persists, and remounting it every beat would throw that away and flash. The HTML
  path keeps its per-beat key: a new string is a new figure and has nothing to preserve.
- **Read and Watch are untouched.** A live figure cannot be joined as markup — `SlideDeck`
  concatenates every step into one canvas and `BlogView` shows the last — so those lenses go on
  showing the slide HTML, which is the snapshot of the same beat. One data model, one additive
  field, two lenses that never learn about it.

A function cannot come from JSON, so `figure` is not part of the authoring model: `assemblePost`
builds sections from post.json + Markdown, and the consumer attaches `figure` to them. The beat a
figure is handed carries `sectionKey`, `step` and `index` — which beat it is being asked to draw.

## Quick start

```jsx
import { PostView, StoryDeckProvider } from 'storydeck/react';
import 'storydeck/storydeck.css';

export default function App({ post }) {
  return (
    <StoryDeckProvider basePath="/blog">
      <PostView post={post} />
    </StoryDeckProvider>
  );
}
```

`PostView` renders the Read · Scroll · Watch toggle and each lens. Bring your own `post` (see
**Authoring**). The React lenses require the optional `react`/`react-dom` peers. The Watch runtime is bundled and
registered when mounted; consumers no longer need to copy a runtime into their public directory.

## Authoring (JSON structure + Markdown prose)

A post is a folder — **JSON** for structure + grouping, **Markdown** for prose:

```
post.json     { …meta, sections: [{ key, label, heading, slides: [deckLabel…] }] }
body.md       Markdown per section, split by  <!--section:key-->  markers
deck-data.json  the slides ({ label, html }[]) — e.g. imported from a Claude Design deck
```

The consumer wires these together with the adapter:

```js
import { assemblePost } from 'storydeck';
const post = assemblePost({ meta, sections, bodyMd, deckSlides });
```

## Theming (bring your own)

storydeck hardcodes **no colours** — it reads a CSS-variable token contract, so the consumer owns
the look:

```
--bg --bg-elev --fg --fg-muted --fg-faint --line --line2
--yellow (accent)  --accent-ink (readable accent)  --sans --mono --content
```

Headless theme control:

```jsx
import { useTheme, ThemeToggle } from 'storydeck/react';
const { theme, toggle, setTheme } = useTheme();   // flips an html class + persists
// …or drop in <ThemeToggle />
```

## API

| Export | What |
|---|---|
| `storydeck/react`: `PostView` | the lens controller (Read · Scroll · Watch toggle) |
| `storydeck/react`: `BlogView` · `ScrollyView` · `SlideDeck` · `LiveSlideDeck` | the three lenses (take `sections` / `sections` / `steps`) |
| `storydeck/react`: `SlideFigure` | one slide rendered as a scaled static figure |
| `storydeck/react`: `StoryDeckProvider` · `useBasePath` | inject deploy config (asset base path) |
| `storydeck/react`: `useTheme` · `ThemeToggle` | headless theming + a default toggle |
| `assemblePost` | build a normalized `Post` from JSON + Markdown + slides |
| `renderMarkdown` · `splitBodyByMarkers` | the Markdown adapter pieces |
| `buildSections` · `finalStep` · `allSteps` · `parseGroup` | grouping helpers |
| `slugify` · `scopeDeckCss` | utilities |

Core types ship in `index.d.ts` and `live.d.ts`; optional React types ship in `react.d.ts` — hand-kept (there is no build to generate them from),
and here rather than in a consumer's shim, because a package's shape belongs in the package.

## Tests

```bash
npm test        # vitest
npm run test:cov
```

The tests cover the existing lenses and additive builds, server-safe core imports, stable live shells, controlled React updates, navigation ownership, and cleanup.

## License

MIT © [Sanjay Krishna Anbalagan](https://github.com/sanjay1909) — part of the
[footprintjs ecosystem](https://footprintjs.github.io/).
