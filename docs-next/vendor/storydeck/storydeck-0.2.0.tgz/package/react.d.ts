import type { CSSProperties, ReactElement, ReactNode } from 'react';
import type { Section as CoreSection, Post as CorePost } from './index.js';
import type { LiveSlide, LiveSlideContext, LiveDeckOptions, NavigationIntent } from './live.js';

export interface ScrollyBeat {
  readonly key: string;
  readonly index: number;
  readonly html: string;
  readonly label: string;
  readonly heading: string;
  readonly body: string;
  readonly sectionKey: string;
  readonly step: number;
  readonly firstOfSection: boolean;
  readonly figure: ((beat: ScrollyBeat) => ReactNode) | null;
}
export interface Section extends CoreSection {
  readonly figure?: (beat: ScrollyBeat) => ReactNode;
}
export interface Post extends CorePost { readonly sections: readonly Section[]; }
export function PostView(props: { post: Post }): ReactElement;
export function BlogView(props: { sections: readonly Section[] }): ReactElement;
export function ScrollyView(props: { sections: readonly Section[] }): ReactElement;
export function SlideDeck(props: { steps: readonly string[] }): ReactElement;
export function SlideFigure(props: { html: string }): ReactElement;
export function ThemeToggle(): ReactElement;
export function StoryDeckProvider(props: { basePath?: string; children?: ReactNode }): ReactElement;
export function useBasePath(): string;
export function useTheme(): { theme: 'light' | 'dark'; setTheme: (next: 'light' | 'dark') => void; toggle: () => void };
export function LiveSlideDeck<S extends LiveSlide = LiveSlide>(props: {
  slides: readonly S[];
  index?: number;
  renderSlide: (context: LiveSlideContext<S>) => ReactNode;
  onIndexChange?: LiveDeckOptions<S>['onIndexChange'];
  onNavigate?: (intent: NavigationIntent) => void;
  className?: string;
  style?: CSSProperties;
}): ReactElement;
